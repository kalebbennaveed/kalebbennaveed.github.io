from dataclasses import replace

import jax.numpy as jnp
import numpy as np
import pytest

from jax_mppi import make_env
from jax_mppi.demo import default_config, run_episode


def test_double_integrator_constant_acceleration():
    e = make_env("point_mass")
    np.testing.assert_allclose(
        e.step(jnp.zeros(4), jnp.array([2.0, -2.0])), [0.01, -0.01, 0.2, -0.2], atol=1e-7
    )


def test_unicycle_straight_and_turning():
    e = make_env("unicycle")
    np.testing.assert_allclose(e.step(jnp.zeros(3), jnp.array([1.0, 0.0])), [0.1, 0, 0], atol=1e-7)
    np.testing.assert_allclose(
        e.step(jnp.zeros(3), jnp.array([1.0, 2.0])),
        [np.sin(0.2) / 2, (1 - np.cos(0.2)) / 2, 0.2],
        atol=1e-7,
    )


def test_pendulum_equilibrium_and_torque_direction():
    e = make_env("pendulum")
    np.testing.assert_allclose(e.step(jnp.zeros(2), jnp.zeros(1)), [0, 0])
    assert float(e.step(jnp.zeros(2), jnp.ones(1))[1]) > 0


@pytest.mark.parametrize("name", ["point_mass", "unicycle", "pendulum"])
@pytest.mark.parametrize("mode", ["mppi", "smppi"])
def test_episode_is_finite_bounded_and_reproducible(name, mode):
    e = make_env(name)
    cfg = replace(default_config(e, mode), horizon=8, samples=32, iterations=1)
    d1 = run_episode(name, steps=5, config=cfg)
    d2 = run_episode(name, steps=5, config=cfg)
    np.testing.assert_array_equal(d1["states"], d2["states"])
    assert np.isfinite(d1["states"]).all()
    a = np.asarray(d1["controls"])
    assert np.all(a >= np.array(e.lower) - 1e-6)
    assert np.all(a <= np.array(e.upper) + 1e-6)
    assert np.shape(d1["plans"]) == (5, 9, len(e.initial))
    assert np.all(np.asarray(d1["ess"]) >= 1 - 1e-5)
