from dataclasses import replace

import jax
import jax.numpy as jnp
import numpy as np
import pytest

from jax_mppi import MPPI, MPPIConfig, make_env, shift_sequence
from jax_mppi.core import corrected_scores, normalized_weights


def test_likelihood_correction_matches_gaussian_log_densities():
    rng = np.random.default_rng(12)
    u = rng.normal(size=(4, 2))
    eps = rng.normal(size=(50, 4, 2))
    sigma = np.array([0.7, 1.3])
    costs = rng.uniform(size=50)
    for nu in (0.5, 1, 2):
        lam = 0.8
        v = u + eps
        log_p = -0.5 * np.sum(v**2 / sigma**2, axis=(1, 2)) - 4 * np.log(sigma).sum()
        log_q = (
            -0.5 * np.sum(eps**2 / (nu * sigma**2), axis=(1, 2))
            - 4 * np.log(np.sqrt(nu) * sigma).sum()
        )
        direct = costs + lam * (log_q - log_p)
        actual = np.asarray(
            corrected_scores(
                jnp.array(costs), jnp.array(u), jnp.array(eps), jnp.array(sigma), lam, nu
            )
        )
        # Scores differ by a common constant, so compare relative to sample 0.
        np.testing.assert_allclose(actual - actual[0], direct - direct[0], rtol=2e-5, atol=3e-6)


def test_weights_stable_shift_invariant_and_invalid_handling():
    w, valid = normalized_weights(jnp.array([1e6, 1e6 + 1, jnp.inf, jnp.nan]), 1.0)
    expected = np.array([1, np.exp(-1), 0, 0])
    np.testing.assert_allclose(w, expected / expected.sum(), atol=1e-7)
    assert valid
    invalid, valid = normalized_weights(jnp.array([jnp.inf, jnp.nan, -jnp.inf]), 1.0)
    np.testing.assert_array_equal(invalid, [0, 0, 0])
    assert not valid


def test_hand_calculated_update_and_terminal_cost():
    cfg = MPPIConfig(horizon=1, samples=3, sigma=(1.0,), iterations=1)
    ctrl = MPPI(
        lambda x, a: a,
        lambda x: jnp.float32(0),
        lambda x: (x[0] - 2) ** 2,
        (-100,),
        (100,),
        0.1,
        cfg,
    )
    mean = jnp.ones((1, 1))
    noise = jnp.array([[[-1.0]], [[0.0]], [[1.0]]])
    updated, actions, weights, scores, _, valid = ctrl.update_with_noise(
        jnp.zeros(1), mean, mean, noise
    )
    np.testing.assert_allclose(scores, [3, 1, 1])
    expected = np.exp(-np.array([2, 0, 0]))
    expected /= expected.sum()
    np.testing.assert_allclose(weights, expected, atol=1e-7)
    np.testing.assert_allclose(updated, [[expected[1] + 2 * expected[2]]], atol=1e-7)
    np.testing.assert_array_equal(updated, actions)
    assert valid


@pytest.mark.parametrize("nu", [0.6, 1.0, 1.7])
def test_importance_sampling_recovers_known_gaussian_target(nu):
    # p=N(0,1), S(v)=(v-2)^2/2, lambda=1 -> target N(1,1/2).
    cfg = MPPIConfig(horizon=1, samples=80000, sigma=(1.0,), covariance_scale=nu)
    ctrl = MPPI(
        lambda x, a: a,
        lambda x: jnp.float32(0),
        lambda x: 0.5 * (x[0] - 2) ** 2,
        (-100,),
        (100,),
        0.1,
        cfg,
    )
    result = ctrl.update(jax.random.key(51), jnp.zeros(1), jnp.array([[0.4]]), jnp.zeros((1, 1)))
    assert abs(float(result.mean[0, 0]) - 1.0) < 0.02


def test_rollout_cost_indexing_and_shapes():
    cfg = MPPIConfig(horizon=2)
    ctrl = MPPI(
        lambda x, a: x + a, lambda x: x[0] ** 2, lambda x: 10 * x[0] ** 2, (-10,), (10,), 1, cfg
    )
    cost, states = ctrl.rollout(jnp.array([1.0]), jnp.array([[2.0], [3.0]]))
    np.testing.assert_array_equal(states, [[1], [3], [6]])
    assert float(cost) == 1 + 9 + 360  # c(x0)+c(x1)+phi(x2), no off-by-one


def test_saturation_preserves_raw_gaussian_update():
    cfg = MPPIConfig(horizon=1, samples=2)
    ctrl = MPPI(
        lambda x, a: a, lambda x: jnp.float32(0), lambda x: jnp.float32(0), (-1,), (1,), 1, cfg
    )
    updated, actions, _, _, _, _ = ctrl.update_with_noise(
        jnp.zeros(1), jnp.zeros((1, 1)), jnp.zeros((1, 1)), jnp.array([[[10.0]], [[2.0]]])
    )
    np.testing.assert_allclose(updated, [[6]])
    np.testing.assert_allclose(actions, [[1]])


def test_smppi_uses_iteration_axis_action_update_and_adjacent_penalty():
    cfg = MPPIConfig(horizon=3, samples=1, mode="smppi", smooth_weight=2)
    ctrl = MPPI(
        lambda x, a: x + a,
        lambda x: jnp.float32(0),
        lambda x: jnp.float32(0),
        (-10,),
        (10,),
        0.1,
        cfg,
    )
    base = jnp.array([[1.0], [2.0], [3.0]])
    mean = jnp.array([[2.0], [4.0], [6.0]])
    updated, actions, _, _, _, _ = ctrl.update_with_noise(
        jnp.zeros(1), mean, base, jnp.zeros((1, 3, 1))
    )
    np.testing.assert_allclose(actions, [[1.2], [2.4], [3.6]], atol=1e-6)
    np.testing.assert_allclose(updated, mean)
    cost, _ = ctrl.rollout(jnp.zeros(1), actions)
    np.testing.assert_allclose(cost, 2 * (1.2**2 + 1.2**2), atol=1e-6)


def test_all_invalid_keeps_previous_plan():
    cfg = MPPIConfig(horizon=2, samples=8, mode="smppi")
    ctrl = MPPI(
        lambda x, a: x,
        lambda x: jnp.float32(jnp.inf),
        lambda x: jnp.float32(0),
        (-5,),
        (5,),
        0.1,
        cfg,
    )
    mean, base = jnp.ones((2, 1)), jnp.ones((2, 1)) * 2
    result = ctrl.update(jax.random.key(0), jnp.zeros(1), mean, base)
    assert not result.valid
    assert float(result.ess) == 0
    np.testing.assert_array_equal(result.mean, mean)
    np.testing.assert_array_equal(result.actions, base)


def test_random_key_and_shift():
    env = make_env("point_mass")
    cfg = MPPIConfig(horizon=3, samples=16, sigma=env.sigma)
    ctrl = MPPI(env.step, env.state_cost, env.terminal_cost, env.lower, env.upper, env.dt, cfg)
    u, a = ctrl.initial_sequences()
    key = jax.random.key(3)
    x = jnp.array(env.initial)
    r1, r2 = ctrl.update(key, x, u, a), ctrl.update(key, x, u, a)
    np.testing.assert_array_equal(r1.mean, r2.mean)
    r3 = ctrl.update(r1.key, x, u, a)
    assert not np.array_equal(r1.mean, r3.mean)
    np.testing.assert_array_equal(shift_sequence(jnp.array([[1], [2], [3]])), [[2], [3], [3]])
    np.testing.assert_array_equal(shift_sequence(jnp.array([[1]])), [[1]])


@pytest.mark.parametrize(
    "changes",
    [
        {"temperature": 0},
        {"sigma": (0,)},
        {"horizon": 0},
        {"samples": 1.5},
        {"covariance_scale": -1},
        {"smooth_weight": float("nan")},
    ],
)
def test_bad_config_rejected(changes):
    with pytest.raises(ValueError):
        replace(MPPIConfig(), **changes)
