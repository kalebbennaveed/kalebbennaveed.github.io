"""Run with: uv run python examples/minimal.py"""

import jax
import jax.numpy as jnp

from jax_mppi import MPPI, make_env, shift_sequence
from jax_mppi.demo import default_config

env = make_env("point_mass")
controller = MPPI(
    env.step, env.state_cost, env.terminal_cost, env.lower, env.upper, env.dt, default_config(env)
)
key = jax.random.key(0)
state = jnp.array(env.initial, dtype=jnp.float32)
mean, actions = controller.initial_sequences()
plant_step = jax.jit(env.step)
for step in range(env.steps):
    result = controller.optimize(key, state, mean, actions)
    if not bool(result.valid):
        raise RuntimeError("No finite rollout; no action applied")
    key = result.key
    state = plant_step(state, result.actions[0])
    mean = shift_sequence(result.mean)
    actions = shift_sequence(result.actions)
print("Final state:", state)
