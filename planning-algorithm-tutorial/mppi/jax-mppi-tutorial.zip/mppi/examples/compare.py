"""Run both methods on every requested seed, retaining failures in the results."""

import argparse
import csv
import json
from pathlib import Path

from jax_mppi.demo import default_config, run_episode, write_outputs
from jax_mppi.envs import make_env


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2])
    parser.add_argument(
        "--envs",
        nargs="+",
        choices=["point_mass", "unicycle", "pendulum"],
        default=["point_mass", "unicycle", "pendulum"],
    )
    parser.add_argument("--output", type=Path, default=Path("outputs/comparison"))
    parser.add_argument("--save-episodes", action="store_true")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    records = []
    for name in args.envs:
        for mode in ("mppi", "smppi"):
            for seed in args.seeds:
                data = run_episode(name, seed=seed, config=default_config(make_env(name), mode))
                row = dict(environment=name, mode=mode, seed=seed, **data["metrics"])
                print(json.dumps(row), flush=True)
                records.append(dict(**row, config=data["config"], versions=data["versions"]))
                if args.save_episodes:
                    write_outputs(data, args.output / f"{name}-{mode}-{seed}")
    (args.output / "validation.json").write_text(json.dumps(records, indent=2, allow_nan=False))
    rows = [{k: v for k, v in r.items() if k not in ("config", "versions")} for r in records]
    with (args.output / "comparison.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    main()
