"""Closed-loop experiments, plots, and an offline animation."""

import argparse
import json
import time
from dataclasses import asdict, replace
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np

from .core import MPPI, MPPIConfig, shift_sequence
from .envs import make_env


def default_config(env, mode="mppi"):
    # A derivative perturbation with sigma/dt produces the same action-scale
    # perturbation in SMPPI. This is a teaching default, not a paper setting.
    sigma = env.sigma if mode == "mppi" else tuple(s / env.dt for s in env.sigma)
    return MPPIConfig(
        horizon=env.horizon,
        sigma=sigma,
        temperature=env.temperature,
        mode=mode,
        samples=512 if env.name == "unicycle" else 1024,
        iterations=1 if env.name == "point_mass" else 2,
    )


def run_episode(name="point_mass", *, seed=0, steps=None, config=None):
    env = make_env(name)
    config = config or default_config(env)
    steps = env.steps if steps is None else steps
    if not isinstance(steps, int) or isinstance(steps, bool) or steps < 1:
        raise ValueError("steps must be a positive integer")
    if not isinstance(seed, int) or not 0 <= seed < 2**32:
        raise ValueError("seed must be an integer in [0, 2**32)")
    controller = MPPI(
        env.step, env.state_cost, env.terminal_cost, env.lower, env.upper, env.dt, config
    )
    state = jnp.asarray(env.initial, dtype=jnp.float32)
    mean, actions = controller.initial_sequences()
    key = jax.random.key(seed)
    # Compile and synchronize separately; this call does not consume our key.
    begin = time.perf_counter()
    warm = controller.update(key, state, mean, actions)
    jax.block_until_ready(warm)
    compile_seconds = time.perf_counter() - begin
    states, controls, ess, seconds, costs, plans = [np.asarray(state)], [], [], [], [], []
    plant_step = jax.jit(env.step)
    for _ in range(steps):
        begin = time.perf_counter()
        result = controller.optimize(key, state, mean, actions)
        jax.block_until_ready(result)
        seconds.append(time.perf_counter() - begin)
        if not bool(result.valid):
            raise RuntimeError(
                "All sampled costs are nonfinite; check the model and costs. No action was applied."
            )
        key = result.key
        action = result.actions[0]
        costs.append(float(env.state_cost(state)))
        controls.append(np.asarray(action))
        ess.append(float(result.ess))
        _, predicted = controller.rollout(state, result.actions)
        plans.append(np.asarray(predicted))
        state = plant_step(state, action)
        states.append(np.asarray(state))
        mean = shift_sequence(result.mean)
        actions = shift_sequence(result.actions)
    states, controls = np.asarray(states), np.asarray(controls)
    if not np.isfinite(states).all():
        raise RuntimeError("The simulated plant produced a nonfinite state")
    total_cost = float(sum(costs) + env.terminal_cost(state))
    if name == "pendulum":
        error = np.arctan2(np.sin(states[-1, 0] - np.pi), np.cos(states[-1, 0] - np.pi))
        goal_error = abs(float(error))
        success = goal_error < 0.2 and abs(states[-1, 1]) < 0.5
        clearance = None
    else:
        goal_error = float(np.linalg.norm(states[-1, :2] - np.array(env.goal[:2])))
        # Segment checks catch between-step crossings for the plotted positions;
        # they are still not continuous-time safety certificates.
        p, d = states[:-1, :2], np.diff(states[:, :2], axis=0)
        clearances = []
        for cx, cy, radius in env.obstacles:
            center = np.array([cx, cy])
            alpha = np.clip(
                np.sum((center - p) * d, axis=1) / np.maximum(np.sum(d * d, axis=1), 1e-12), 0, 1
            )
            clearances.append(np.linalg.norm(p + alpha[:, None] * d - center, axis=1) - radius)
        clearance = float(np.min(clearances)) if clearances else None
        success = goal_error < 0.3 and (clearance is None or clearance >= 0)
        if name == "point_mass":
            success = success and np.linalg.norm(states[-1, 2:]) < 0.5
    return dict(
        environment=name,
        seed=seed,
        dt=env.dt,
        config=asdict(config),
        states=states.tolist(),
        controls=controls.tolist(),
        plans=np.asarray(plans).tolist(),
        state_costs=costs,
        ess=ess,
        solve_seconds=seconds,
        goal=env.goal,
        obstacles=env.obstacles,
        state_labels=env.state_labels,
        input_labels=env.input_labels,
        metrics=dict(
            goal_error=goal_error,
            success=bool(success),
            minimum_clearance=clearance,
            total_state_cost=total_cost,
            action_variation=float(np.sum(np.diff(controls, axis=0) ** 2)),
            median_ess=float(np.median(ess)),
            median_solve_ms=1000 * float(np.median(seconds)),
            compilation_seconds=compile_seconds,
        ),
        versions=dict(jax=jax.__version__, numpy=np.__version__, backend=jax.default_backend()),
    )


def save_plot(data, path):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import Circle

    states, controls = np.array(data["states"]), np.array(data["controls"])
    t = np.arange(len(states)) * data["dt"]
    fig, axes = plt.subplots(2, 2, figsize=(11, 7), constrained_layout=True)
    ax = axes[0, 0]
    if data["environment"] == "pendulum":
        ax.plot(t, np.arctan2(np.sin(states[:, 0] - np.pi), np.cos(states[:, 0] - np.pi)))
        ax.set(xlabel="Time [s]", ylabel="Angle from upright [rad]")
    else:
        ax.plot(states[:, 0], states[:, 1], color="#316b80")
        ax.scatter(*states[0, :2], label="Start", color="#316b80")
        ax.scatter(*data["goal"][:2], marker="*", s=140, label="Goal", color="#a85431")
        for x, y, r in data["obstacles"]:
            ax.add_patch(Circle((x, y), r, color="#d7c4b4"))
        ax.set(xlabel="x [m]", ylabel="y [m]", aspect="equal")
        ax.legend()
    for j, label in enumerate(data["input_labels"]):
        axes[0, 1].plot(t[:-1], controls[:, j], label=label)
    axes[0, 1].set(xlabel="Time [s]", ylabel="Applied input")
    axes[0, 1].legend()
    axes[1, 0].plot(t[:-1], data["state_costs"])
    axes[1, 0].set(xlabel="Time [s]", ylabel="State cost per step")
    axes[1, 1].plot(t[:-1], data["ess"])
    axes[1, 1].set(
        xlabel="Time [s]", ylabel="Effective sample size", ylim=(0, data["config"]["samples"])
    )
    for ax in axes.flat:
        ax.grid(alpha=0.2)
    fig.suptitle(f"{data['config']['mode'].upper()} · {data['environment']} · seed {data['seed']}")
    fig.savefig(path, dpi=160)
    plt.close(fig)


def write_outputs(data, output):
    from .playground import render_page

    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    (output / "episode.json").write_text(json.dumps(data, indent=2, allow_nan=False))
    np.savez_compressed(
        output / "episode.npz",
        states=data["states"],
        controls=data["controls"],
        ess=data["ess"],
        state_costs=data["state_costs"],
    )
    save_plot(data, output / "summary.png")
    (output / "playback.html").write_text(render_page(data=data, live=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--env", choices=["point_mass", "unicycle", "pendulum"], default="point_mass"
    )
    parser.add_argument("--mode", choices=["mppi", "smppi"], default="mppi")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--steps", type=int)
    parser.add_argument("--samples", type=int)
    parser.add_argument("--horizon", type=int)
    parser.add_argument("--iterations", type=int)
    parser.add_argument("--temperature", type=float)
    parser.add_argument(
        "--noise-scale", type=float, default=1.0, help="multiply prior standard deviations"
    )
    parser.add_argument(
        "--covariance-scale", type=float, default=1.0, help="proposal covariance multiplier nu"
    )
    parser.add_argument("--smooth-weight", type=float, default=1.0)
    parser.add_argument("--output", type=Path, default=Path("outputs/demo"))
    args = parser.parse_args()
    config = default_config(make_env(args.env), args.mode)
    changes = {
        name: getattr(args, name)
        for name in ("samples", "horizon", "iterations", "temperature")
        if getattr(args, name) is not None
    }
    config = replace(
        config,
        **changes,
        sigma=tuple(s * args.noise_scale for s in config.sigma),
        covariance_scale=args.covariance_scale,
        smooth_weight=args.smooth_weight,
    )
    data = run_episode(args.env, seed=args.seed, steps=args.steps, config=config)
    write_outputs(data, args.output)
    print(json.dumps(data["metrics"], indent=2))
    print(f"Saved {args.output.resolve() / 'playback.html'}")


if __name__ == "__main__":
    main()
