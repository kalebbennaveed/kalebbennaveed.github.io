"""Local browser controls for the actual JAX solver; no JavaScript solver."""

import argparse
import json
from dataclasses import replace
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

from .demo import default_config, run_episode
from .envs import make_env


def render_page(data=None, live=True):
    template = Path(__file__).with_name("playground.html").read_text()
    payload = json.dumps(data, allow_nan=False).replace("<", "\\u003c")
    return template.replace("__INITIAL_DATA__", payload).replace("__LIVE__", str(live).lower())


def run_request(params):
    name = params.get("env", "point_mass")
    env = make_env(name)
    cfg = default_config(env, params.get("mode", "mppi"))
    values = {
        name: int(params.get(name, getattr(cfg, name)))
        for name in ("samples", "horizon", "iterations")
    }
    steps = int(params.get("steps", env.steps))
    if not (
        16 <= values["samples"] <= 4096
        and 2 <= values["horizon"] <= 120
        and 1 <= values["iterations"] <= 5
        and 1 <= steps <= 400
    ):
        raise ValueError("Use 16–4096 samples, horizon 2–120, 1–5 iterations, and 1–400 steps")
    noise_scale = float(params.get("noise_scale", 1))
    cfg = replace(
        cfg,
        **values,
        temperature=float(params.get("temperature", cfg.temperature)),
        sigma=tuple(s * noise_scale for s in cfg.sigma),
        covariance_scale=float(params.get("covariance_scale", 1)),
        smooth_weight=float(params.get("smooth_weight", 1)),
    )
    return run_episode(name, seed=int(params.get("seed", 0)), steps=steps, config=cfg)


class Handler(BaseHTTPRequestHandler):
    def respond(self, status, body, content_type):
        encoded = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type + "; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(encoded)

    def do_GET(self):
        if self.path != "/":
            self.respond(404, "Not found", "text/plain")
            return
        self.respond(200, render_page(), "text/html")

    def do_POST(self):
        if self.path != "/run":
            self.respond(404, "Not found", "text/plain")
            return
        # Only the same local page may submit a simulation.
        origin = self.headers.get("Origin")
        expected = f"http://{self.headers.get('Host')}"
        if origin and origin != expected:
            self.respond(403, '{"error":"Origin rejected"}', "application/json")
            return
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if not 0 < size <= 4096:
                raise ValueError("Invalid request size")
            params = json.loads(self.rfile.read(size))
            if not isinstance(params, dict):
                raise ValueError("Expected an object of settings")
            data = run_request(params)
            self.respond(200, json.dumps(data, allow_nan=False), "application/json")
        except (ValueError, TypeError, KeyError, RuntimeError) as exc:
            self.respond(400, json.dumps({"error": str(exc)}), "application/json")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()
    server = HTTPServer(("127.0.0.1", args.port), Handler)
    print(f"Open http://127.0.0.1:{args.port} — Ctrl+C to stop", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
