"""Teaching examples, not reproductions of the papers' experiments.

Double integrator and unicycle: models in the existing Kaleb Notes.
Pendulum: the notes' point-mass pendulum, with theta=0 downward.
All parameter values and navigation costs below are tutorial choices.
"""

from collections.abc import Callable
from dataclasses import dataclass

import jax.numpy as jnp


@dataclass(frozen=True)
class Environment:
    name: str
    dt: float
    initial: tuple
    goal: tuple
    lower: tuple
    upper: tuple
    sigma: tuple
    horizon: int
    temperature: float
    steps: int
    step: Callable
    state_cost: Callable
    terminal_cost: Callable
    obstacles: tuple = ()  # (center_x, center_y, radius), includes robot size
    state_labels: tuple = ()
    input_labels: tuple = ()


def wrap_angle(angle):
    return jnp.arctan2(jnp.sin(angle), jnp.cos(angle))


def obstacle_cost(position, obstacles):
    total = jnp.float32(0.0)
    for cx, cy, radius in obstacles:
        clearance = jnp.linalg.norm(position - jnp.array([cx, cy])) - radius
        total += 1200.0 * jnp.maximum(0.0, 0.35 - clearance) ** 2
        total += 2000.0 * (clearance < 0.0)
    return total


def make_env(name: str) -> Environment:
    if name == "point_mass":
        dt = 0.1
        goal = (3.0, 1.5, 0.0, 0.0)
        obstacles = ((0.0, 0.0, 0.65),)

        def step(x, a):
            return jnp.concatenate((x[:2] + dt * x[2:] + 0.5 * dt**2 * a, x[2:] + dt * a))

        def cost(x):
            return dt * (
                3.0 * jnp.sum((x[:2] - jnp.array(goal[:2])) ** 2)
                + 0.5 * jnp.sum(x[2:] ** 2)
                + obstacle_cost(x[:2], obstacles)
            )

        def terminal(x):
            return 25.0 * jnp.sum((x[:2] - jnp.array(goal[:2])) ** 2) + 8.0 * jnp.sum(x[2:] ** 2)

        return Environment(
            name,
            dt,
            (-3.0, -1.0, 0.0, 0.0),
            goal,
            (-2.0, -2.0),
            (2.0, 2.0),
            (3.0, 3.0),
            25,
            3.0,
            100,
            step,
            cost,
            terminal,
            obstacles,
            ("x [m]", "y [m]", "vx [m/s]", "vy [m/s]"),
            ("ax [m/s²]", "ay [m/s²]"),
        )
    if name == "unicycle":
        dt = 0.1
        goal = (3.0, 1.5, 0.0)
        obstacles = ((0.0, 0.0, 0.65),)

        def step(x, a):
            # Exact constant-input unicycle step, continuous at angular rate=0.
            travel = dt * a[0] * jnp.sinc(dt * a[1] / (2 * jnp.pi))
            mid = x[2] + 0.5 * dt * a[1]
            return x + jnp.array([travel * jnp.cos(mid), travel * jnp.sin(mid), dt * a[1]])

        def cost(x):
            return dt * (
                4.0 * jnp.sum((x[:2] - jnp.array(goal[:2])) ** 2) + obstacle_cost(x[:2], obstacles)
            )

        def terminal(x):
            return 30.0 * jnp.sum((x[:2] - jnp.array(goal[:2])) ** 2)

        return Environment(
            name,
            dt,
            (-3.0, -1.0, 0.0),
            goal,
            (-1.5, -2.0),
            (1.5, 2.0),
            (1.0, 1.5),
            40,
            0.8,
            100,
            step,
            cost,
            terminal,
            obstacles,
            ("x [m]", "y [m]", "heading [rad]"),
            ("v [m/s]", "yaw rate [rad/s]"),
        )
    if name == "pendulum":
        dt = 0.05

        # m=l=1, g=9.81, viscous damping b=0.1. Angle zero is downward.
        def derivative(x, a):
            return jnp.array([x[1], a[0] - 0.1 * x[1] - 9.81 * jnp.sin(x[0])])

        def step(x, a):
            k1 = derivative(x, a)
            k2 = derivative(x + 0.5 * dt * k1, a)
            k3 = derivative(x + 0.5 * dt * k2, a)
            k4 = derivative(x + dt * k3, a)
            return x + dt * (k1 + 2 * k2 + 2 * k3 + k4) / 6.0

        def cost(x):
            error = wrap_angle(x[0] - jnp.pi)
            return dt * (error**2 + 0.1 * x[1] ** 2)

        def terminal(x):
            error = wrap_angle(x[0] - jnp.pi)
            return 10.0 * error**2 + x[1] ** 2

        return Environment(
            name,
            dt,
            (0.0, 0.0),
            (float(jnp.pi), 0.0),
            (-3.0,),
            (3.0,),
            (3.0,),
            60,
            0.15,
            240,
            step,
            cost,
            terminal,
            (),
            ("angle [rad]", "angular velocity [rad/s]"),
            ("torque [N m]",),
        )
    raise ValueError(f"unknown environment {name!r}; choose point_mass, unicycle, or pendulum")
