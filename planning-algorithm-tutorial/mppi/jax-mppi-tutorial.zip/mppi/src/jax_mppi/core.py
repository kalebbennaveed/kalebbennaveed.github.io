"""Gaussian MPPI, matching the equations in the companion tutorial.

Kim et al. (2022), Eqs. (1)-(10); covariance correction follows the
Gaussian likelihood-ratio calculation in Williams et al. (2017), Sec. III.
SMPPI uses Kim et al., Eqs. (15)-(18), with saturation inside the rollout.
"""

import math
from collections.abc import Callable
from dataclasses import dataclass
from typing import NamedTuple

import jax
import jax.numpy as jnp

Array = jax.Array


@dataclass(frozen=True)
class MPPIConfig:
    horizon: int = 40
    samples: int = 512
    temperature: float = 1.0
    sigma: tuple[float, ...] = (1.0,)
    covariance_scale: float = 1.0
    iterations: int = 2
    mode: str = "mppi"
    smooth_weight: float = 1.0

    def __post_init__(self):
        for name in ("horizon", "samples", "iterations"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 1:
                raise ValueError(f"{name} must be a positive integer")
        for name in ("temperature", "covariance_scale"):
            value = getattr(self, name)
            if not math.isfinite(value) or value <= 0:
                raise ValueError(f"{name} must be finite and positive")
        if not self.sigma or any(not math.isfinite(s) or s <= 0 for s in self.sigma):
            raise ValueError("sigma must contain finite positive standard deviations")
        if self.mode not in ("mppi", "smppi"):
            raise ValueError("mode must be 'mppi' or 'smppi'")
        if not math.isfinite(self.smooth_weight) or self.smooth_weight < 0:
            raise ValueError("smooth_weight must be finite and nonnegative")


class Update(NamedTuple):
    key: Array
    mean: Array  # (H, m), Gaussian mean in the sampling coordinates
    actions: Array  # (H, m), physical inputs after the action map
    weights: Array  # (K,), final batch's normalized weights
    scores: Array  # (K,), cost including the likelihood correction
    ess: Array  # scalar, 1 / sum(weights**2)
    valid: Array  # scalar boolean, at least one finite sample


def normalized_weights(scores: Array, temperature: float) -> tuple[Array, Array]:
    """Zero weight for nonfinite scores; all-invalid gives zeros and False."""
    finite = jnp.isfinite(scores)
    valid = jnp.any(finite)
    minimum = jnp.min(jnp.where(finite, scores, jnp.inf))
    minimum = jnp.where(valid, minimum, 0.0)
    # Mask before exp: invalid model evaluations must not poison valid samples.
    shifted = jnp.where(finite, scores - minimum, jnp.inf)
    unnormalized = jnp.exp(-shifted / temperature)
    weights = unnormalized / jnp.maximum(jnp.sum(unnormalized), 1.0)
    return weights, valid


def corrected_scores(
    state_costs: Array,
    mean: Array,
    noise: Array,
    sigma: Array,
    temperature: float,
    covariance_scale: float = 1.0,
) -> Array:
    """S + lambda log(q/p), dropping terms constant across this batch.

    p = product N(0, diag(sigma**2));
    q = product N(mean[t], covariance_scale * diag(sigma**2)).
    noise is the RAW Gaussian perturbation, before applying actuator bounds.
    """
    cross = jnp.sum(mean[None, :, :] * noise / sigma**2, axis=(1, 2))
    variance = 0.5 * (1.0 - 1.0 / covariance_scale) * jnp.sum((noise / sigma) ** 2, axis=(1, 2))
    return state_costs + temperature * (cross + variance)


def shift_sequence(sequence: Array) -> Array:
    """Discard the applied entry and repeat the last entry (including H=1)."""
    return jnp.concatenate((sequence[1:], sequence[-1:]), axis=0)


class MPPI:
    """Compile one rollout and one update for fixed dynamics and dimensions.

    step(x, a) -> x_next, state_cost(x) -> scalar, terminal_cost(x) -> scalar.
    Costs supplied here are discrete costs: include dt in state_cost if needed.
    For ordinary MPPI, actions_base is ignored. For SMPPI, it is the stored
    action sequence A from the preceding optimization iteration.
    """

    def __init__(
        self,
        step: Callable,
        state_cost: Callable,
        terminal_cost: Callable,
        lower,
        upper,
        dt: float,
        config: MPPIConfig,
    ):
        self.config = config
        m = len(config.sigma)
        if len(lower) != m or len(upper) != m:
            raise ValueError("bounds and sigma must have the same input dimension")
        if any(not math.isfinite(float(v)) for v in (*lower, *upper)):
            raise ValueError("action bounds must be finite")
        if any(lo >= hi for lo, hi in zip(lower, upper)):
            raise ValueError("each lower bound must be below its upper bound")
        if not math.isfinite(dt) or dt <= 0:
            raise ValueError("dt must be finite and positive")
        self.lower = jnp.asarray(lower, dtype=jnp.float32)
        self.upper = jnp.asarray(upper, dtype=jnp.float32)
        sigma = jnp.asarray(config.sigma, dtype=jnp.float32)

        def action_map(raw, base):
            candidate = base + dt * raw if config.mode == "smppi" else raw
            return jnp.clip(candidate, self.lower, self.upper)

        def rollout(x0, actions):
            def advance(x, action):
                cost = state_cost(x)  # c(x_t), BEFORE the state transition
                nxt = step(x, action)
                return nxt, (nxt, cost)

            last, (states, costs) = jax.lax.scan(advance, x0, actions)
            total = jnp.sum(costs) + terminal_cost(last)
            if config.mode == "smppi":
                # Kim et al. Eq. (15): adjacent predicted actions, t=1,...,H-1.
                total += config.smooth_weight * jnp.sum(jnp.diff(actions, axis=0) ** 2)
            return total, jnp.concatenate((x0[None, :], states), axis=0)

        batch_rollout = jax.vmap(rollout, in_axes=(None, 0))

        def update_with_noise(x0, mean, actions_base, noise):
            raw = mean[None, :, :] + noise
            sampled_actions = action_map(raw, actions_base)
            costs, _ = batch_rollout(x0, sampled_actions)
            scores = corrected_scores(
                costs, mean, noise, sigma, config.temperature, config.covariance_scale
            )
            weights, valid = normalized_weights(scores, config.temperature)
            # Do not substitute clipped perturbations in this Gaussian identity.
            new_mean = mean + jnp.einsum("k,ktm->tm", weights, noise)
            new_mean = jnp.where(valid, new_mean, mean)
            new_actions = action_map(new_mean, actions_base)
            old_actions = actions_base if config.mode == "smppi" else action_map(mean, actions_base)
            new_actions = jnp.where(valid, new_actions, old_actions)
            ess = jnp.where(valid, 1.0 / jnp.maximum(jnp.sum(weights**2), 1e-30), 0.0)
            return new_mean, new_actions, weights, scores, ess, valid

        def update(key, x0, mean, actions_base):
            key, draw_key = jax.random.split(key)
            noise = jax.random.normal(draw_key, (config.samples, config.horizon, m))
            noise = noise * sigma * math.sqrt(config.covariance_scale)
            values = update_with_noise(x0, mean, actions_base, noise)
            return Update(key, *values)

        self.action_map = jax.jit(action_map)
        self.rollout = jax.jit(rollout)
        self.update_with_noise = jax.jit(update_with_noise)
        self.update = jax.jit(update)

    def initial_sequences(self):
        shape = (self.config.horizon, len(self.config.sigma))
        mean = jnp.zeros(shape, dtype=jnp.float32)
        actions = jnp.clip(jnp.zeros(shape, dtype=jnp.float32), self.lower, self.upper)
        return mean, actions

    def optimize(self, key, state, mean, actions):
        """A few updates from one measured state; no horizon shift here."""
        for _ in range(self.config.iterations):
            result = self.update(key, state, mean, actions)
            key, mean, actions = result.key, result.mean, result.actions
        return result
