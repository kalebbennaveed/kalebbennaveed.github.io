# Rebuild the website copy

From the `mppi` project directory, with Pandoc available on PATH:

```bash
uv run python examples/compare.py --save-episodes --output outputs/validation
uv run python tools/build_site.py \
  --destination ../../../kalebbennaveed.github.io/planning-algorithm-tutorial/mppi
```

The first command records all seeds and both controller modes, including failures. The second uses those records to publish three seed-zero MPPI playback pages, copies the full comparison results, renders the implementation walkthrough from the root README, and packages source files plus the lockfile and license. It excludes the virtual environment, caches, and generated output directory. It does not push or deploy a website.

For the theory chapter, from the sibling `kaleb_notes` repository with R, bookdown, and Pandoc installed:

```bash
Rscript -e 'bookdown::render_book("index.Rmd", "bookdown::gitbook")'
```

The existing GitHub Pages workflow builds that book after its source changes are published.
