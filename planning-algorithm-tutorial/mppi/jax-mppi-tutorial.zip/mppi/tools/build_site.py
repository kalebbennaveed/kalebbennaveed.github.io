"""Build the static tutorial and source archive after running examples/compare.py.

Requires Pandoc on PATH; this is a maintainer command, not needed to run MPPI.
"""

import argparse
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--destination", type=Path, required=True)
    parser.add_argument("--results", type=Path, default=Path("outputs/validation"))
    args = parser.parse_args()
    project = Path(__file__).resolve().parents[1]
    destination = args.destination.resolve()
    destination.mkdir(parents=True, exist_ok=True)
    results = args.results.resolve()
    for env in ("point_mass", "unicycle", "pendulum"):
        target = destination / "examples" / env
        target.mkdir(parents=True, exist_ok=True)
        for name in ("summary.png", "playback.html", "episode.json", "episode.npz"):
            shutil.copyfile(results / f"{env}-mppi-0" / name, target / name)
    for name in ("validation.json", "comparison.csv"):
        shutil.copyfile(results / name, project / name)
        shutil.copyfile(results / name, destination / name)
    shutil.copyfile(project / "SOURCES.md", destination / "SOURCES.md")
    with tempfile.TemporaryDirectory() as temporary:
        markdown = Path(temporary) / "tutorial.md"
        # The template provides the single page title and recorded examples.
        text = (project / "README.md").read_text().split("\n", 1)[1]
        markdown.write_text(text)
        subprocess.run(
            [
                "pandoc",
                str(markdown),
                "--from=markdown",
                "--to=html5",
                "--standalone",
                "--toc",
                "--toc-depth=2",
                "--mathjax",
                "--metadata",
                "title=MPPI in JAX",
                "--template",
                str(project / "tools/site-template.html"),
                "--output",
                str(destination / "index.html"),
            ],
            check=True,
        )
    excluded = {".venv", "__pycache__", ".pytest_cache", ".ruff_cache", "outputs", ".git"}
    with zipfile.ZipFile(
        destination / "jax-mppi-tutorial.zip", "w", zipfile.ZIP_DEFLATED
    ) as archive:
        for path in sorted(project.rglob("*")):
            relative = path.relative_to(project)
            if path.is_file() and not any(part in excluded for part in relative.parts):
                archive.write(path, Path("mppi") / relative)
    print(f"Built {destination / 'index.html'}")


if __name__ == "__main__":
    main()
